import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leads-sidebar',
  templateUrl: './leads-sidebar.component.html',
  styleUrls: ['./leads-sidebar.component.css']
})
export class LeadsSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
