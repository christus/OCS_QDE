import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-successfull',
  templateUrl: './payment-successfull.component.html',
  styleUrls: ['./payment-successfull.component.css']
})
export class PaymentSuccessfullComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
