import Qde from "./qde.model";

export default class RequestEntity {
    processId : string;
    ProcessVariables : any;
    workflowId : string;
    projectId : string;
}
